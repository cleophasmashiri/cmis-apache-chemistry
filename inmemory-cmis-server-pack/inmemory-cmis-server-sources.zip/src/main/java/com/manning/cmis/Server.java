/**
 * Copyright 2012 Manning Publications Co.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.manning.cmis;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.catalina.deploy.FilterDef;
import org.apache.catalina.deploy.FilterMap;
import org.apache.catalina.startup.Tomcat;
import org.apache.chemistry.opencmis.commons.server.CmisServiceFactory;
import org.apache.chemistry.opencmis.server.impl.CmisRepositoryContextListener;
import org.apache.chemistry.opencmis.server.support.filter.LoggingFilter;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Server {

	private static final int DEFAULT_PORT = 8081;

	private static final String WEBAPP = "inmemory-cmis-server-webapp.zip";
	private static final String CONTENT = "inmemory-cmis-server-content.zip";

	private static final String SERVER_PORT = "cmis.server.port";
	private static final String SERVER_WORK_DIR = "cmis.server.workdir";
	private static final String SERVER_WEBAPP = "cmis.server.webapp";
	private static final String SERVER_CONTENT = "cmis.server.content";
	private static final String SERVER_LOG_LEVEL = "cmis.server.loglevel";
	private static final String SERVER_RECORD = "cmis.server.record";

	private static final int BUFFER = 4096;

	private Tomcat tomcat;
	private Context ctx;
	private int port;
	private boolean record;
	private File workDir;
	private File baseDir;
	private File webDir;
	private File recordDir;

	/**
	 * InMemory CMIS Server.
	 */
	public Server() throws Exception {
		System.out.println("\n:: InMemory CMIS Server ::\n");

		// get port
		try {
			port = Integer.parseInt(System.getProperty(SERVER_PORT,
					String.valueOf(DEFAULT_PORT)));
		} catch (Exception e) {
			port = DEFAULT_PORT;
			System.err
					.println("Invalid port! Using default port " + port + ".");
		}

		// get work directory
		String workDirPath = System.getProperty(SERVER_WORK_DIR, ".");

		// record requests?
		record = Boolean
				.parseBoolean(System.getProperty(SERVER_RECORD, "true"));

		// create directories
		workDir = new File(workDirPath);
		baseDir = new File(workDir, "cmis");
		webDir = new File(baseDir, "webapps" + File.separatorChar + "inmemory");
		recordDir = new File(workDir, "record");
	}

	/**
	 * Starts the server.
	 */
	public void start() throws Exception {
		createWebApp();
		setupLoggers();
		startTomcat();
		loadInitialContent();
		finish();
	}

	/**
	 * Returns the context address.
	 */
	private String getContextAddress() {
		Connector con = tomcat.getConnector();
		return con.getScheme() + "://" + tomcat.getHost().getName() + ":"
				+ con.getPort() + ctx.getPath();
	}

	/**
	 * Creates the web app directory and unpacks the web app content.
	 */
	private void createWebApp() throws Exception {
		System.out.println("Creating work directory '"
				+ workDir.getCanonicalPath() + "' ...");

		if (!webDir.exists()) {
			if (!webDir.mkdirs()) {
				System.err.println("Could not create directory: "
						+ webDir.getCanonicalPath());
				return;
			}
		}

		if (record) {
			if (!recordDir.exists()) {
				recordDir.mkdirs();
			}
		}

		File webapp = new File(System.getProperty(SERVER_WEBAPP, WEBAPP));

		System.out.println("Unpacking webapp '" + webapp.getCanonicalPath()
				+ "' to '" + webDir.getCanonicalPath() + "' ...");

		unzipWebApp(webapp, webDir);
	}

	/**
	 * Sets up the loggers.
	 */
	private void setupLoggers() {
		String logLevel = System.getProperty(SERVER_LOG_LEVEL,
				Level.WARN.toString());

		System.out.println("Setting log level to " + logLevel + " ...");

		Logger.getRootLogger().setLevel(Level.toLevel(logLevel));
		java.util.logging.Logger.getLogger("").setLevel(
				java.util.logging.Level.WARNING);
	}

	/**
	 * Starts the embedded Tomcat.
	 */
	private void startTomcat() throws Exception {
		System.out.println("Starting Tomcat on port " + port + " ...");

		tomcat = new Tomcat();
		tomcat.setPort(port);
		tomcat.setSilent(true);

		tomcat.setBaseDir(baseDir.getCanonicalPath());
		tomcat.getHost().setAppBase(webDir.getCanonicalPath());

		ctx = tomcat.addWebapp("/inmemory", webDir.getCanonicalPath());
		ctx.addWelcomeFile("index.jsp");

		if (record) {
			FilterDef filterDef = new FilterDef();
			filterDef.setFilterName("LoggingFilter");
			filterDef.setFilterClass(LoggingFilter.class.getName());
			filterDef.addInitParameter("LogDir", recordDir.getCanonicalPath());
			filterDef.addInitParameter("PrettyPrint", "true");
			filterDef.addInitParameter("LogHeader", "true");
			filterDef.addInitParameter("Indent", "4");
			ctx.addFilterDef(filterDef);

			FilterMap filterMap = new FilterMap();
			filterMap.setFilterName("LoggingFilter");
			filterMap.addURLPattern("/services/*");
			filterMap.addURLPattern("/atom/*");
			filterMap.addURLPattern("/browser/*");
			ctx.addFilterMap(filterMap);
		}

		tomcat.start();
	}

	/**
	 * Loads the initial content into the repository.
	 */
	private void loadInitialContent() throws Exception {
		File content = new File(System.getProperty(SERVER_CONTENT, CONTENT));
		if (content.exists()) {
			System.out.println("Loading content from '"
					+ content.getCanonicalPath() + "' ...");

			CmisServiceFactory factory = (CmisServiceFactory) ctx
					.getServletContext().getAttribute(
							CmisRepositoryContextListener.SERVICES_FACTORY);
			InitialContentLoader filler = new InitialContentLoader(factory);
			filler.add(content);
		}
	}

	/**
	 * Prints final information and waits for the server shutdown.
	 */
	private void finish() {
		System.out.println("\nServer started.\n");

		// print memory
		Runtime.getRuntime().gc();
		System.out.println("Max memory: "
				+ (Runtime.getRuntime().maxMemory() / (1024 * 1024)) + "MB");
		System.out.println();

		// print binding URLs
		String ctxAdr = getContextAddress();
		System.out.println("CMIS Web Services Binding: " + ctxAdr
				+ "/services/RepositoryService?wsdl");
		System.out.println("CMIS AtomPub Binding:      " + ctxAdr + "/atom");
		System.out.println("CMIS Browser Binding:      " + ctxAdr + "/browser");

		// now wait...
		System.out.println("\nPress Ctrl+C to shutdown the server.\n");

		tomcat.getServer().await();
	}

	/**
	 * Unpacks the web app zip file into a directory.
	 */
	private void unzipWebApp(File zip, File dir) throws ZipException,
			IOException {
		ZipInputStream zipStream = new ZipInputStream(new BufferedInputStream(
				new FileInputStream(zip)));
		try {
			ZipEntry entry;
			while ((entry = zipStream.getNextEntry()) != null) {

				// build path
				StringBuilder path = new StringBuilder();
				for (String s : entry.getName().split("/")) {
					if (path.length() > 0) {
						path.append(File.separator);
					}
					path.append(s);
				}

				File file = new File(dir, path.toString());

				// create directories and write file
				if (entry.isDirectory()) {
					file.mkdirs();
				} else {
					file.getParentFile().mkdirs();

					BufferedOutputStream out = new BufferedOutputStream(
							new FileOutputStream(file), BUFFER);

					byte[] buffer = new byte[BUFFER];
					int b;
					while ((b = zipStream.read(buffer)) > -1) {
						out.write(buffer, 0, b);
					}

					out.flush();
					out.close();
				}

				zipStream.closeEntry();
			}
		} finally {
			zipStream.close();
		}
	}

	public static void main(String[] args) throws Exception {
		(new Server()).start();
	}
}
