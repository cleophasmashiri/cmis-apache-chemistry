Find the latest CMIS information and specification here: 

https://www.oasis-open.org/committees/cmis/